#version 120

// Accio Simple Shaders - water/translucent vertex (gentle waves)

attribute vec4 mc_Entity;

uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying float isWater;

#define WATER_WAVE_HEIGHT 0.035 // [0.0 0.02 0.035 0.05 0.08]

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;

    vec4 pos = gl_Vertex;
    isWater = 0.0;

    if (mc_Entity.x == 10003.0) {
        isWater = 1.0;
        float t = frameTimeCounter;
        // Two overlapping sine waves for a natural look
        float wave = sin(t * 1.6 + pos.x * 1.2 + pos.z * 0.8)
                   + sin(t * 1.1 - pos.x * 0.7 + pos.z * 1.5) * 0.6;
        pos.y += wave * WATER_WAVE_HEIGHT;
    }

    gl_Position = gl_ModelViewProjectionMatrix * pos;
    gl_FogFragCoord = length((gl_ModelViewMatrix * pos).xyz);
}
