#version 120

// Accio Simple Shaders - terrain vertex (waving leaves & plants)

attribute vec4 mc_Entity;

uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

#define WAVING_STRENGTH 0.05 // [0.0 0.025 0.05 0.075 0.1]

float hash(vec3 p) {
    return fract(sin(dot(p, vec3(12.9898, 78.233, 45.164))) * 43758.5453);
}

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;

    vec4 pos = gl_Vertex;
    float blockId = mc_Entity.x;

    float t = frameTimeCounter * 2.0;
    float phase = hash(floor(pos.xyz)) * 6.2831;

    if (blockId == 10001.0) {
        // Leaves: whole block sways
        float sway = sin(t + phase + pos.x * 0.5 + pos.z * 0.5);
        pos.x += sway * WAVING_STRENGTH;
        pos.z += cos(t * 0.7 + phase) * WAVING_STRENGTH * 0.7;
    }
    else if (blockId == 10002.0) {
        // Plants: only top vertices wave (texcoord check via lightmap-independent trick)
        if (gl_MultiTexCoord0.t < 0.5 || fract(pos.y + 0.001) > 0.01) {
            float sway = sin(t + phase + pos.x + pos.z);
            pos.x += sway * WAVING_STRENGTH * 1.4;
            pos.z += cos(t * 0.8 + phase) * WAVING_STRENGTH;
        }
    }

    gl_Position = gl_ModelViewProjectionMatrix * pos;
    gl_FogFragCoord = length((gl_ModelViewMatrix * pos).xyz);
}
