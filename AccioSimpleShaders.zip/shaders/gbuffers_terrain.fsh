#version 120

// Accio Simple Shaders - terrain fragment

uniform sampler2D texture;
uniform sampler2D lightmap;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    color.rgb *= texture2D(lightmap, lmcoord).rgb;

    // Distance fog
    float fogFactor = clamp((gl_Fog.end - gl_FogFragCoord) * gl_Fog.scale, 0.0, 1.0);
    color.rgb = mix(gl_Fog.color.rgb, color.rgb, fogFactor);

/* DRAWBUFFERS:0 */
    gl_FragData[0] = color;
}
