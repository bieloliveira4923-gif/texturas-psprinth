#version 120

// Accio Simple Shaders - composite: color grading + vignette

uniform sampler2D colortex0;

varying vec2 texcoord;

#define SATURATION 1.15  // [0.8 1.0 1.15 1.3 1.5]
#define CONTRAST   1.06  // [1.0 1.03 1.06 1.1 1.15]
#define BRIGHTNESS 1.02  // [0.9 1.0 1.02 1.05 1.1]
#define VIGNETTE_STRENGTH 0.25 // [0.0 0.15 0.25 0.35 0.5]

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    // Saturation
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    color = mix(vec3(luma), color, SATURATION);

    // Contrast around mid-gray
    color = (color - 0.5) * CONTRAST + 0.5;

    // Brightness
    color *= BRIGHTNESS;

    // Vignette
    vec2 uv = texcoord - 0.5;
    float vig = 1.0 - dot(uv, uv) * VIGNETTE_STRENGTH * 2.0;
    color *= clamp(vig, 0.0, 1.0);

/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(clamp(color, 0.0, 1.0), 1.0);
}
