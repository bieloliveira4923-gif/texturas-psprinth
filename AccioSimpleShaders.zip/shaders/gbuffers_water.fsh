#version 120

// Accio Simple Shaders - water/translucent fragment

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying float isWater;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    color.rgb *= texture2D(lightmap, lmcoord).rgb;

    if (isWater > 0.5) {
        // Subtle animated tint + slightly higher transparency
        float shimmer = 0.92 + 0.08 * sin(frameTimeCounter * 2.0 + texcoord.x * 40.0);
        color.rgb *= vec3(0.85, 0.95, 1.05) * shimmer;
        color.a *= 0.85;
    }

    // Distance fog
    float fogFactor = clamp((gl_Fog.end - gl_FogFragCoord) * gl_Fog.scale, 0.0, 1.0);
    color.rgb = mix(gl_Fog.color.rgb, color.rgb, fogFactor);

/* DRAWBUFFERS:0 */
    gl_FragData[0] = color;
}
