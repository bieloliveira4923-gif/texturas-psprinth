# Accio Simple Shaders v1.0

A lightweight shaderpack for **Minecraft Java 1.20.x** using **Iris + Sodium** (also works with OptiFine).

## Features
- Waving leaves, grass, flowers and crops
- Animated water waves with a subtle blue shimmer
- Distance fog
- Color grading: saturation, contrast, brightness
- Soft vignette
- All effects adjustable in Shader Pack Settings

## Installation
1. Install **Fabric Loader** for 1.20.x
2. Put **Sodium** and **Iris** in your `mods` folder
   - Sodium: https://modrinth.com/mod/sodium
   - Iris: https://modrinth.com/mod/iris
3. Copy `AccioSimpleShaders.zip` into `.minecraft/shaderpacks/`
4. In game: Options → Video Settings → Shader Packs → select **AccioSimpleShaders**

## Tuning
Open "Shader Pack Settings" in game to adjust waving strength, water waves,
saturation, contrast, brightness and vignette.

## Notes
- Uses GLSL 120 for maximum compatibility (works on old and new GPUs).
- Very light on performance — designed to keep Sodium-level FPS.
